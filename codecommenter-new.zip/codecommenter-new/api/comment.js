/**
 * Vercel Serverless Function: /api/comment
 * CommonJS handler for Code Commenter Agent
 * 
 * Supports:
 * - GET: Health & AI readiness check (200 if GEMINI_API_KEY present, 503 if missing)
 * - POST: Generates documented code using Google Gemini API with 25s timeout
 * - OPTIONS: Preflight CORS handling
 */

module.exports = async (req, res) => {
  // CORS & Cache-Control headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');

  // Helper for consistent JSON responses in Vercel and Node.js
  const sendJson = (statusCode, payload) => {
    if (typeof res.setHeader === 'function') {
      res.setHeader('Content-Type', 'application/json');
    }
    if (typeof res.status === 'function') {
      const chained = res.status(statusCode);
      if (chained && typeof chained.json === 'function') {
        return chained.json(payload);
      }
    }
    if (typeof res.json === 'function') {
      res.statusCode = statusCode;
      return res.json(payload);
    }
    res.statusCode = statusCode;
    if (typeof res.end === 'function') {
      res.end(JSON.stringify(payload));
    }
  };

  // 1. Handle OPTIONS preflight
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;

  // 2. Handle GET (Health & Readiness Check)
  if (req.method === 'GET') {
    if (!apiKey) {
      return sendJson(503, {
        error: 'GEMINI_API_KEY is not configured',
        status: 'offline',
        mode: 'offline'
      });
    }

    return sendJson(200, {
      status: 'ok',
      mode: 'ready',
      version: '1.0.0',
      timestamp: new Date().toISOString()
    });
  }

  // 3. Handle POST (Code Comment Generation)
  if (req.method === 'POST') {
    if (!apiKey) {
      return sendJson(503, {
        error: 'GEMINI_API_KEY is not configured',
        status: 'offline'
      });
    }

    // Parse request body safely across Vercel and Node environments
    let body = req.body;
    if (body === undefined && typeof req.on === 'function') {
      try {
        const chunks = [];
        for await (const chunk of req) {
          chunks.push(chunk);
        }
        const raw = Buffer.concat(chunks).toString('utf8');
        body = raw ? JSON.parse(raw) : {};
      } catch (parseErr) {
        return sendJson(400, { error: 'Invalid JSON payload in request body' });
      }
    } else if (typeof body === 'string') {
      try {
        body = JSON.parse(body);
      } catch (parseErr) {
        return sendJson(400, { error: 'Invalid JSON payload in request body' });
      }
    }

    const { code, language = 'python', style = 'detailed' } = body || {};

    if (!code || typeof code !== 'string' || !code.trim()) {
      return sendJson(400, { error: 'Missing or empty code parameter' });
    }

    // Build comment style instructions
    const styleInstructions = {
      concise: 'Add minimal, high-impact inline comments explaining non-obvious logic and flow.',
      detailed: 'Add thorough, step-by-step explanatory comments for all key operations and logic blocks.',
      docstring: 'Add professional docstrings/JSDoc/standard documentation comments for all functions, methods, and classes, including parameter types and return descriptions.'
    };
    const chosenStyle = styleInstructions[style] || styleInstructions.detailed;

    const prompt = `You are an expert software engineer and automated code documentation engine.
Add clean, professional comments to the following ${language} code according to this specification:
${chosenStyle}

CRITICAL RULES:
1. Preserve all existing code logic, variable names, functions, and indentation exactly as provided.
2. Return ONLY the documented code.
3. Do NOT include markdown code fences (like \`\`\` or \`\`\`${language}), and do NOT include any conversational preamble or outro text.
4. Output raw code only.

SOURCE CODE:
${code}`;

    // 25-second fetch timeout using AbortController
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);

    try {
      const geminiEndpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`;

      const geminiResp = await fetch(geminiEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.2
          }
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!geminiResp.ok) {
        // If 2.5-flash endpoint is unavailable, attempt fallback to 1.5-flash
        if (geminiResp.status === 404) {
          const fallbackEndpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`;
          const fallbackResp = await fetch(fallbackEndpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ parts: [{ text: prompt }] }],
              generationConfig: { temperature: 0.2 }
            })
          });

          if (fallbackResp.ok) {
            const fallbackResult = await fallbackResp.json();
            let commentedCode = fallbackResult.candidates?.[0]?.content?.parts?.[0]?.text || '';
            if (commentedCode.startsWith('```')) {
              commentedCode = commentedCode.replace(/^```[a-zA-Z0-9_-]*\r?\n/, '').replace(/\r?\n```$/, '');
            }
            return sendJson(200, {
              status: 'ok',
              commentedCode: commentedCode.trimEnd() + '\n',
              received: {
                language,
                style,
                codeLength: code.length
              }
            });
          }
        }

        const errData = await geminiResp.json().catch(() => ({}));
        const errMsg = errData.error?.message || `Gemini API returned HTTP ${geminiResp.status}`;
        return sendJson(502, {
          error: 'AI generation error',
          message: errMsg,
          status: 'error'
        });
      }

      const result = await geminiResp.json();
      let commentedCode = result.candidates?.[0]?.content?.parts?.[0]?.text || '';

      // Strip markdown code fences if model enclosed output in them
      if (commentedCode.startsWith('```')) {
        commentedCode = commentedCode.replace(/^```[a-zA-Z0-9_-]*\r?\n/, '').replace(/\r?\n```$/, '');
      }

      return sendJson(200, {
        status: 'ok',
        commentedCode: commentedCode.trimEnd() + '\n',
        received: {
          language,
          style,
          codeLength: code.length
        }
      });
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        return sendJson(504, {
          error: 'Gemini API request timed out after 25 seconds',
          status: 'timeout'
        });
      }
      return sendJson(500, {
        error: 'Internal server error while generating comments',
        message: err.message,
        status: 'error'
      });
    }
  }

  // 4. Handle Unsupported HTTP Methods
  return sendJson(405, { error: `Method ${req.method} not allowed` });
};
