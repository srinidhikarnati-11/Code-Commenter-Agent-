/**
 * Code Commenter Agent - Application Logic & Controller
 * Implements Monaco / Fallback editor, pipeline stepper animation,
 * drag-and-drop, tabs, diff, tree, toasts, shortcuts, and localStorage persistence.
 */

(function () {
  'use strict';

  // State Management
  const state = {
    language: 'python',
    commentStyle: 'concise', // concise | detailed | docstring
    theme: 'dark',
    sourceCode: '',
    commentedCode: '',
    summaryData: null,
    elementsData: null,
    diffData: null,
    isGenerating: false,
    activeTab: 'code',
    monacoReady: false,
    monacoEditor: null,
    isOfflineMode: true,
    firstRender: true
  };

  // DOM Elements
  const DOM = {
    // Topbar
    statusPill: document.getElementById('status-pill'),
    statusPillText: document.getElementById('status-pill-text'),
    btnThemeToggle: document.getElementById('btn-theme-toggle'),
    linkHowItWorks: document.getElementById('link-how-it-works'),

    // Pipeline
    pipelineSection: document.getElementById('pipeline-section'),
    pipelineProgress: document.getElementById('pipeline-progress'),
    stepNodes: [
      document.getElementById('step-node-1'),
      document.getElementById('step-node-2'),
      document.getElementById('step-node-3'),
      document.getElementById('step-node-4'),
      document.getElementById('step-node-5')
    ],

    // Source Panel
    selectLanguage: document.getElementById('select-language'),
    btnLoadSample: document.getElementById('btn-load-sample'),
    inputFileUpload: document.getElementById('input-file-upload'),
    btnClearSource: document.getElementById('btn-clear-source'),
    monacoHost: document.getElementById('monaco-editor-host'),
    fallbackWrapper: document.getElementById('fallback-editor-wrapper'),
    fallbackTextarea: document.getElementById('fallback-textarea'),
    editorLineNumbers: document.getElementById('editor-line-numbers'),
    dropOverlay: document.getElementById('drop-overlay'),
    sourceDropzone: document.getElementById('source-editor-dropzone'),
    sourceStatLines: document.getElementById('source-stat-lines'),
    sourceStatChars: document.getElementById('source-stat-chars'),

    // Resizer
    panelResizer: document.getElementById('panel-resizer'),
    panelSource: document.getElementById('panel-source'),
    panelResult: document.getElementById('panel-result'),
    workspaceGrid: document.getElementById('workspace-grid'),

    // Result Panel
    tabBtnCode: document.getElementById('tab-btn-code'),
    tabBtnSummary: document.getElementById('tab-btn-summary'),
    tabBtnElements: document.getElementById('tab-btn-elements'),
    tabBtnDiff: document.getElementById('tab-btn-diff'),
    tabsUnderline: document.getElementById('tabs-underline'),
    btnCopyResult: document.getElementById('btn-copy-result'),
    copyBtnText: document.getElementById('copy-btn-text'),
    copyIcon: document.getElementById('copy-icon'),
    btnDownloadResult: document.getElementById('btn-download-result'),
    btnFullscreenToggle: document.getElementById('btn-fullscreen-toggle'),
    skeletonLoader: document.getElementById('skeleton-loader'),
    resultStatMode: document.getElementById('result-stat-mode'),
    resultStatLines: document.getElementById('result-stat-lines'),

    // Tab Panes
    paneCode: document.getElementById('pane-code'),
    emptyStateResult: document.getElementById('empty-state-result'),
    codeViewerWrapper: document.getElementById('code-viewer-wrapper'),
    codeDisplayBody: document.getElementById('code-display-body'),

    paneSummary: document.getElementById('pane-summary'),
    emptyStateSummary: document.getElementById('empty-state-summary'),
    summaryContentWrapper: document.getElementById('summary-content-wrapper'),
    summaryWhatItDoes: document.getElementById('summary-what-it-does'),
    summaryComplexityBadge: document.getElementById('summary-complexity-badge'),
    summaryComplexityText: document.getElementById('summary-complexity-text'),
    summarySpaceText: document.getElementById('summary-space-text'),
    summaryIssuesContainer: document.getElementById('summary-issues-container'),

    paneElements: document.getElementById('pane-elements'),
    emptyStateElements: document.getElementById('empty-state-elements'),
    elementsContentWrapper: document.getElementById('elements-content-wrapper'),
    elementsTreeRoot: document.getElementById('elements-tree-root'),

    paneDiff: document.getElementById('pane-diff'),
    emptyStateDiff: document.getElementById('empty-state-diff'),
    diffContentWrapper: document.getElementById('diff-content-wrapper'),
    diffRowsContainer: document.getElementById('diff-rows-container'),

    // Action Bar
    segmentBtns: document.querySelectorAll('.segment-btn'),
    btnGenerateComments: document.getElementById('btn-generate-comments'),

    // Toast Container
    toastContainer: document.getElementById('toast-container')
  };

  /* ==========================================================================
     Initialization & Persistence
     ========================================================================== */
  function init() {
    loadPreferences();
    setupTheme();
    setupStatusCheck();
    setupTabs();
    setupResizer();
    setupMonacoOrFallback();
    setupFileHandlers();
    setupActions();
    setupKeyboardShortcuts();
    updateTabsUnderline();

    // If sourceCode was saved or empty, set sample on initial run if empty
    if (!state.sourceCode || !state.sourceCode.trim()) {
      state.sourceCode = (DOM.fallbackTextarea && DOM.fallbackTextarea.value) || (window.CodeCommenterEngine && window.CodeCommenterEngine.SAMPLES['python']) || '';
    }
    setSourceCode(state.sourceCode);
  }

  function loadPreferences() {
    try {
      const savedLang = localStorage.getItem('cca_language');
      if (savedLang && ['python', 'javascript', 'typescript', 'java', 'cpp', 'go', 'rust'].includes(savedLang)) {
        state.language = savedLang;
        DOM.selectLanguage.value = savedLang;
      }
      const savedStyle = localStorage.getItem('cca_comment_style');
      if (savedStyle && ['concise', 'detailed', 'docstring'].includes(savedStyle)) {
        state.commentStyle = savedStyle;
        DOM.segmentBtns.forEach(btn => {
          const isActive = btn.dataset.style === savedStyle;
          btn.classList.toggle('segment-active', isActive);
          btn.setAttribute('aria-checked', isActive ? 'true' : 'false');
        });
      }
      const savedTheme = localStorage.getItem('cca_theme');
      if (savedTheme) {
        state.theme = savedTheme;
      }
      const savedCode = localStorage.getItem('cca_last_code');
      if (savedCode) {
        state.sourceCode = savedCode;
      } else if (DOM.fallbackTextarea && DOM.fallbackTextarea.value) {
        state.sourceCode = DOM.fallbackTextarea.value;
      }
    } catch (e) {
      console.warn('localStorage access failed or blocked:', e);
    }
  }

  function savePreference(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
  }

  /* ==========================================================================
     Theme Management
     ========================================================================== */
  function setupTheme() {
    document.documentElement.setAttribute('data-theme', state.theme);
    updateThemeIcon();

    DOM.btnThemeToggle.addEventListener('click', () => {
      state.theme = state.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', state.theme);
      savePreference('cca_theme', state.theme);
      updateThemeIcon();

      if (state.monacoReady && state.monacoEditor) {
        window.monaco.editor.setTheme(state.theme === 'dark' ? 'midnight-theme' : 'vs');
      }
    });
  }

  function updateThemeIcon() {
    const isDark = state.theme === 'dark';
    DOM.btnThemeToggle.setAttribute('aria-label', isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode');
    DOM.btnThemeToggle.innerHTML = isDark
      ? `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <circle cx="12" cy="12" r="5"></circle>
          <line x1="12" y1="1" x2="12" y2="3"></line>
          <line x1="12" y1="21" x2="12" y2="23"></line>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
          <line x1="1" y1="12" x2="3" y2="12"></line>
          <line x1="21" y1="12" x2="23" y2="12"></line>
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
          <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
        </svg>`
      : `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
        </svg>`;
  }

  /* ==========================================================================
     API Health / Status Pill Check
     ========================================================================== */
  async function setupStatusCheck() {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);

      const resp = await fetch('/api/comment', {
        method: 'GET',
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (resp.ok) {
        state.isOfflineMode = false;
        DOM.statusPill.className = 'status-pill status-online';
        DOM.statusPillText.textContent = 'AI ready';
        DOM.resultStatMode.textContent = 'Engine: AI Model Active';
        return;
      }
    } catch (e) {
      // Offline / server not running
    }

    state.isOfflineMode = true;
    DOM.statusPill.className = 'status-pill status-offline';
    DOM.statusPillText.textContent = 'Offline mode';
    DOM.resultStatMode.textContent = 'Engine: Intelligent AST Rule-based';
  }

  /* ==========================================================================
     Monaco Editor & Graceful Fallback
     ========================================================================== */
  function setupMonacoOrFallback() {
    // Initialize fallback immediately so there is zero empty-screen delay
    DOM.fallbackWrapper.classList.add('active');
    if (state.sourceCode) {
      DOM.fallbackTextarea.value = state.sourceCode;
      updateLineNumbers();
      updateSourceStats();
    }

    let monacoLoaded = false;
    const fallbackTimer = setTimeout(() => {
      if (!monacoLoaded) {
        activateFallbackTextarea();
      }
    }, 4000);

    // Load Monaco via AMD loader
    if (typeof window.require === 'undefined') {
      const loaderScript = document.createElement('script');
      loaderScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs/loader.min.js';
      loaderScript.async = true;

      loaderScript.onload = () => {
        try {
          window.require.config({
            paths: { vs: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs' }
          });
          window.require(['vs/editor/editor.main'], () => {
            monacoLoaded = true;
            clearTimeout(fallbackTimer);
            initMonacoEditor();
          });
        } catch (err) {
          activateFallbackTextarea();
        }
      };

      loaderScript.onerror = () => {
        activateFallbackTextarea();
      };

      document.head.appendChild(loaderScript);
    } else {
      try {
        window.require(['vs/editor/editor.main'], () => {
          monacoLoaded = true;
          clearTimeout(fallbackTimer);
          initMonacoEditor();
        });
      } catch (err) {
        activateFallbackTextarea();
      }
    }

    // Fallback events
    DOM.fallbackTextarea.addEventListener('input', () => {
      state.sourceCode = DOM.fallbackTextarea.value;
      savePreference('cca_last_code', state.sourceCode);
      updateLineNumbers();
      updateSourceStats();
    });

    DOM.fallbackTextarea.addEventListener('scroll', () => {
      DOM.editorLineNumbers.scrollTop = DOM.fallbackTextarea.scrollTop;
    });

    // Tab key handling in fallback textarea
    DOM.fallbackTextarea.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        e.preventDefault();
        const start = DOM.fallbackTextarea.selectionStart;
        const end = DOM.fallbackTextarea.selectionEnd;
        DOM.fallbackTextarea.value = DOM.fallbackTextarea.value.substring(0, start) + '    ' + DOM.fallbackTextarea.value.substring(end);
        DOM.fallbackTextarea.selectionStart = DOM.fallbackTextarea.selectionEnd = start + 4;
        state.sourceCode = DOM.fallbackTextarea.value;
        updateLineNumbers();
        updateSourceStats();
      }
    });
  }

  function initMonacoEditor() {
    try {
      window.monaco.editor.defineTheme('midnight-theme', {
        base: 'vs-dark',
        inherit: true,
        rules: [
          { token: 'comment', foreground: '6ee7b7', fontStyle: 'italic' },
          { token: 'keyword', foreground: '5eead4' },
          { token: 'string', foreground: 'f5b14c' },
          { token: 'number', foreground: '38bdf8' }
        ],
        colors: {
          'editor.background': '#0b0e14',
          'editor.foreground': '#e6e9f0',
          'editorLineNumber.foreground': '#8b94a7',
          'editorLineNumber.activeForeground': '#5eead4',
          'editor.selectionBackground': '#242c3d',
          'editor.lineHighlightBackground': '#121722',
          'editorCursor.foreground': '#5eead4'
        }
      });

      state.monacoEditor = window.monaco.editor.create(DOM.monacoHost, {
        value: state.sourceCode || DOM.fallbackTextarea.value || '',
        language: mapLanguageToMonaco(state.language),
        theme: state.theme === 'dark' ? 'midnight-theme' : 'vs',
        minimap: { enabled: false },
        fontSize: 14,
        fontFamily: 'JetBrains Mono, ui-monospace, SFMono-Regular, monospace',
        lineNumbers: 'on',
        roundedSelection: true,
        scrollBeyondLastLine: false,
        automaticLayout: true,
        padding: { top: 12, bottom: 12 }
      });

      state.monacoReady = true;
      DOM.monacoHost.style.display = 'block';
      DOM.fallbackWrapper.classList.add('hidden');

      state.monacoEditor.onDidChangeModelContent(() => {
        state.sourceCode = state.monacoEditor.getValue();
        savePreference('cca_last_code', state.sourceCode);
        updateSourceStats();
      });

      updateSourceStats();
    } catch (e) {
      console.warn('Monaco init error, falling back:', e);
      activateFallbackTextarea();
    }
  }

  function activateFallbackTextarea() {
    state.monacoReady = false;
    DOM.monacoHost.style.display = 'none';
    DOM.fallbackWrapper.classList.remove('hidden');
    if (state.sourceCode) {
      DOM.fallbackTextarea.value = state.sourceCode;
    }
    updateLineNumbers();
    updateSourceStats();
  }

  function mapLanguageToMonaco(lang) {
    const map = {
      python: 'python',
      javascript: 'javascript',
      typescript: 'typescript',
      java: 'java',
      cpp: 'cpp',
      go: 'go',
      rust: 'rust'
    };
    return map[lang] || 'plaintext';
  }

  function getSourceCode() {
    if (state.monacoReady && state.monacoEditor) {
      return state.monacoEditor.getValue();
    }
    return DOM.fallbackTextarea.value || state.sourceCode || '';
  }

  function setSourceCode(code) {
    state.sourceCode = code;
    savePreference('cca_last_code', code);
    if (state.monacoReady && state.monacoEditor) {
      state.monacoEditor.setValue(code);
    }
    DOM.fallbackTextarea.value = code;
    updateLineNumbers();
    updateSourceStats();
  }

  function updateLineNumbers() {
    const lines = (DOM.fallbackTextarea.value || '').split('\n').length;
    let nums = '';
    for (let i = 1; i <= Math.max(lines, 1); i++) {
      nums += i + '\n';
    }
    DOM.editorLineNumbers.textContent = nums;
  }

  function updateSourceStats() {
    const code = getSourceCode();
    const lines = code ? code.split('\n').length : 0;
    const chars = code ? code.length : 0;
    DOM.sourceStatLines.textContent = `${lines.toLocaleString()} lines`;
    DOM.sourceStatChars.textContent = `${chars.toLocaleString()} characters`;
  }

  /* ==========================================================================
     Sample Code & Language Selection
     ========================================================================== */
  function loadLanguageSample(lang) {
    if (window.CodeCommenterEngine && window.CodeCommenterEngine.SAMPLES[lang]) {
      const sample = window.CodeCommenterEngine.SAMPLES[lang];
      setSourceCode(sample);
      showToast('Loaded sample for ' + capitalize(lang), 'info');
    }
  }

  /* ==========================================================================
     File Drag and Drop & File Upload
     ========================================================================== */
  function setupFileHandlers() {
    // Language dropdown change
    DOM.selectLanguage.addEventListener('change', (e) => {
      state.language = e.target.value;
      savePreference('cca_language', state.language);
      if (state.monacoReady && state.monacoEditor) {
        window.monaco.editor.setModelLanguage(
          state.monacoEditor.getModel(),
          mapLanguageToMonaco(state.language)
        );
      }
    });

    // Load sample button
    DOM.btnLoadSample.addEventListener('click', () => {
      loadLanguageSample(state.language);
    });

    // Clear button
    DOM.btnClearSource.addEventListener('click', () => {
      setSourceCode('');
      showToast('Source cleared', 'info');
    });

    // Upload file input
    DOM.inputFileUpload.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        handleFileRead(file);
      }
      e.target.value = '';
    });

    // Drag & Drop
    const dropzone = DOM.sourceDropzone;

    ['dragenter', 'dragover'].forEach(name => {
      dropzone.addEventListener(name, (e) => {
        e.preventDefault();
        e.stopPropagation();
        DOM.dropOverlay.classList.add('active');
      });
    });

    ['dragleave', 'drop'].forEach(name => {
      dropzone.addEventListener(name, (e) => {
        e.preventDefault();
        e.stopPropagation();
        DOM.dropOverlay.classList.remove('active');
      });
    });

    dropzone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const file = dt.files[0];
      if (file) {
        handleFileRead(file);
      }
    });
  }

  function handleFileRead(file) {
    const validExts = ['.py', '.js', '.ts', '.java', '.cpp', '.c', '.h', '.hpp', '.go', '.rs', '.txt'];
    const fileName = file.name.toLowerCase();
    const isSupported = validExts.some(ext => fileName.endsWith(ext));

    if (!isSupported) {
      showToast(`Unsupported file type (${file.name}). Please upload a valid source file (.py, .js, .ts, .java, .cpp, .go, .rs).`, 'error', {
        actionText: 'Try another',
        onAction: () => DOM.inputFileUpload.click()
      });
      return;
    }

    // Auto-detect language by extension
    if (fileName.endsWith('.py')) state.language = 'python';
    else if (fileName.endsWith('.js')) state.language = 'javascript';
    else if (fileName.endsWith('.ts')) state.language = 'typescript';
    else if (fileName.endsWith('.java')) state.language = 'java';
    else if (fileName.endsWith('.cpp') || fileName.endsWith('.c') || fileName.endsWith('.h') || fileName.endsWith('.hpp')) state.language = 'cpp';
    else if (fileName.endsWith('.go')) state.language = 'go';
    else if (fileName.endsWith('.rs')) state.language = 'rust';

    DOM.selectLanguage.value = state.language;
    savePreference('cca_language', state.language);
    if (state.monacoReady && state.monacoEditor) {
      window.monaco.editor.setModelLanguage(
        state.monacoEditor.getModel(),
        mapLanguageToMonaco(state.language)
      );
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      setSourceCode(e.target.result);
      showToast(`Loaded "${file.name}" (${(file.size / 1024).toFixed(1)} KB)`, 'success');
    };
    reader.onerror = () => {
      showToast('Failed to read file contents', 'error');
    };
    reader.readAsText(file);
  }

  /* ==========================================================================
     Tabs & Panel Controls
     ========================================================================== */
  function setupTabs() {
    const tabs = [
      { btn: DOM.tabBtnCode, pane: DOM.paneCode, id: 'code' },
      { btn: DOM.tabBtnSummary, pane: DOM.paneSummary, id: 'summary' },
      { btn: DOM.tabBtnElements, pane: DOM.paneElements, id: 'elements' },
      { btn: DOM.tabBtnDiff, pane: DOM.paneDiff, id: 'diff' }
    ];

    tabs.forEach(({ btn, pane, id }) => {
      btn.addEventListener('click', () => {
        tabs.forEach(t => {
          t.btn.classList.remove('tab-active');
          t.btn.setAttribute('aria-selected', 'false');
          t.pane.classList.remove('pane-active');
        });
        btn.classList.add('tab-active');
        btn.setAttribute('aria-selected', 'true');
        pane.classList.add('pane-active');
        state.activeTab = id;
        updateTabsUnderline();
      });
    });

    window.addEventListener('resize', updateTabsUnderline);
  }

  function updateTabsUnderline() {
    const activeBtn = document.querySelector('.tab-btn.tab-active');
    if (activeBtn && DOM.tabsUnderline) {
      DOM.tabsUnderline.style.left = `${activeBtn.offsetLeft}px`;
      DOM.tabsUnderline.style.width = `${activeBtn.offsetWidth}px`;
    }
  }

  /* ==========================================================================
     Draggable Divider (Resizer)
     ========================================================================== */
  function setupResizer() {
    let isDragging = false;

    DOM.panelResizer.addEventListener('mousedown', (e) => {
      isDragging = true;
      DOM.panelResizer.classList.add('dragging');
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const rect = DOM.workspaceGrid.getBoundingClientRect();
      const offset = e.clientX - rect.left;
      const totalWidth = rect.width;
      let percentage = (offset / totalWidth) * 100;

      if (percentage < 20) percentage = 20;
      if (percentage > 80) percentage = 80;

      DOM.panelSource.style.flex = `0 0 ${percentage}%`;
      DOM.panelResult.style.flex = `0 0 ${100 - percentage}%`;
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        DOM.panelResizer.classList.remove('dragging');
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        if (state.monacoReady && state.monacoEditor) {
          state.monacoEditor.layout();
        }
      }
    });

    // Keyboard accessibility for resizer
    DOM.panelResizer.addEventListener('keydown', (e) => {
      const currentFlex = parseFloat(DOM.panelSource.style.flexBasis || 50);
      if (e.key === 'ArrowLeft') {
        const next = Math.max(20, currentFlex - 5);
        DOM.panelSource.style.flex = `0 0 ${next}%`;
        DOM.panelResult.style.flex = `0 0 ${100 - next}%`;
      } else if (e.key === 'ArrowRight') {
        const next = Math.min(80, currentFlex + 5);
        DOM.panelSource.style.flex = `0 0 ${next}%`;
        DOM.panelResult.style.flex = `0 0 ${100 - next}%`;
      }
    });
  }

  /* ==========================================================================
     Actions: Segmented Control, Fullscreen, Copy, Download
     ========================================================================== */
  function setupActions() {
    // Style segmented control
    DOM.segmentBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        DOM.segmentBtns.forEach(b => {
          b.classList.remove('segment-active');
          b.setAttribute('aria-checked', 'false');
        });
        btn.classList.add('segment-active');
        btn.setAttribute('aria-checked', 'true');
        state.commentStyle = btn.dataset.style;
        savePreference('cca_comment_style', state.commentStyle);
      });
    });

    // Generate Comments Button
    DOM.btnGenerateComments.addEventListener('click', handleGenerate);

    // Copy Result
    DOM.btnCopyResult.addEventListener('click', handleCopy);

    // Download Result
    DOM.btnDownloadResult.addEventListener('click', handleDownload);

    // Fullscreen Toggle
    DOM.btnFullscreenToggle.addEventListener('click', () => {
      DOM.panelResult.classList.toggle('fullscreen');
      const isFull = DOM.panelResult.classList.contains('fullscreen');
      DOM.btnFullscreenToggle.classList.toggle('btn-active', isFull);
      DOM.btnFullscreenToggle.setAttribute('aria-label', isFull ? 'Exit Fullscreen' : 'Enter Fullscreen');
      showToast(isFull ? 'Entered fullscreen view' : 'Exited fullscreen view', 'info');
    });

    // "How it works" smooth scroll
    DOM.linkHowItWorks.addEventListener('click', (e) => {
      e.preventDefault();
      DOM.pipelineSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  function handleCopy() {
    if (!state.commentedCode) {
      showToast('No commented code to copy. Generate comments first.', 'info');
      return;
    }

    navigator.clipboard.writeText(state.commentedCode).then(() => {
      DOM.copyBtnText.textContent = 'Copied!';
      DOM.copyIcon.innerHTML = `<polyline points="20 6 9 17 4 12"></polyline>`;
      DOM.btnCopyResult.classList.add('btn-active');
      showToast('Commented code copied to clipboard!', 'success');

      setTimeout(() => {
        DOM.copyBtnText.textContent = 'Copy';
        DOM.copyIcon.innerHTML = `
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
        `;
        DOM.btnCopyResult.classList.remove('btn-active');
      }, 2000);
    }).catch(() => {
      showToast('Failed to copy to clipboard', 'error');
    });
  }

  function handleDownload() {
    if (!state.commentedCode) {
      showToast('No commented code to download. Generate comments first.', 'info');
      return;
    }

    const langObj = window.CodeCommenterEngine.LANGUAGES.find(l => l.id === state.language) || { ext: '.txt' };
    const fileName = `commented_code${langObj.ext}`;
    const blob = new Blob([state.commentedCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Downloaded ${fileName}`, 'success');
  }

  /* ==========================================================================
     Keyboard Shortcuts
     ========================================================================== */
  function setupKeyboardShortcuts() {
    window.addEventListener('keydown', (e) => {
      // Ctrl + Enter or Cmd + Enter => Generate
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        if (!state.isGenerating) {
          handleGenerate();
        }
      }
      // Ctrl + Shift + C => Copy output
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'C' || e.key === 'c')) {
        e.preventDefault();
        handleCopy();
      }
    });
  }

  /* ==========================================================================
     Comment Generation & Pipeline Animation
     ========================================================================== */
  async function handleGenerate() {
    const rawCode = getSourceCode();

    // 1. Validation check
    if (!rawCode || !rawCode.trim()) {
      showPipelineError(1);
      showToast('Input code cannot be empty. Please enter or load code first.', 'error', {
        actionText: 'Load Sample',
        onAction: () => {
          loadLanguageSample(state.language);
          resetPipeline();
        }
      });
      return;
    }

    state.isGenerating = true;
    DOM.btnGenerateComments.disabled = true;
    DOM.btnGenerateComments.classList.add('loading');

    // Show skeleton shimmer in result panel
    DOM.emptyStateResult.style.display = 'none';
    DOM.codeViewerWrapper.style.display = 'none';
    DOM.skeletonLoader.classList.add('active');

    try {
      // Sequential pipeline animation (Nodes 1 to 5)
      await runPipelineStepper();

      // Check if remote API is available or use rule-based engine
      let commentedCode = '';
      if (!state.isOfflineMode) {
        try {
          const resp = await fetch('/api/comment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              code: rawCode,
              language: state.language,
              style: state.commentStyle
            })
          });
          if (resp.ok) {
            const data = await resp.json();
            if (data.commentedCode) {
              commentedCode = data.commentedCode;
            }
          }
        } catch (apiErr) {
          console.warn('API call failed, switching to local rule engine:', apiErr);
          state.isOfflineMode = true;
          DOM.statusPill.className = 'status-pill status-offline';
          DOM.statusPillText.textContent = 'Offline mode';
        }
      }

      // If no remote response, generate via client-side engine
      if (!commentedCode) {
        commentedCode = window.CodeCommenterEngine.generateComments(rawCode, state.language, state.commentStyle);
      }

      // AST & Summary Analysis
      const elements = window.CodeCommenterEngine.parseCodeStructure(rawCode, state.language);
      const summary = window.CodeCommenterEngine.analyzeSummaryAndComplexity(rawCode, state.language, elements);
      const diff = window.CodeCommenterEngine.generateDiff(rawCode, commentedCode, state.language);

      state.commentedCode = commentedCode;
      state.elementsData = elements;
      state.summaryData = summary;
      state.diffData = diff;

      // Render All Views
      renderCommentedCode(commentedCode);
      renderSummary(summary);
      renderElementsTree(elements);
      renderDiff(diff);

      const outLines = commentedCode.split('\n').length;
      DOM.resultStatLines.textContent = `${outLines.toLocaleString()} lines output`;

      showToast('Documentation generated successfully!', 'success');
      state.firstRender = false;
    } catch (err) {
      console.error('Generation error:', err);
      showPipelineError(4);
      showToast('Failed to generate comments. ' + (err.message || 'Unknown error'), 'error', {
        actionText: 'Try again',
        onAction: () => handleGenerate()
      });
    } finally {
      state.isGenerating = false;
      DOM.btnGenerateComments.disabled = false;
      DOM.btnGenerateComments.classList.remove('loading');
      DOM.skeletonLoader.classList.remove('active');
    }
  }

  /* ==========================================================================
     Pipeline Stepper Sequencer
     ========================================================================== */
  function resetPipeline() {
    DOM.stepNodes.forEach((node, i) => {
      node.className = i === 0 ? 'stepper-node completed' : 'stepper-node';
      const icon = node.querySelector('.node-icon-circle');
      if (i === 0) {
        icon.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
      } else {
        icon.textContent = (i + 1).toString();
      }
    });
    DOM.pipelineProgress.style.width = '0%';
  }

  function showPipelineError(failedStepIndex) {
    DOM.stepNodes.forEach((node, i) => {
      if (i + 1 === failedStepIndex) {
        node.className = 'stepper-node error';
        const icon = node.querySelector('.node-icon-circle');
        icon.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;
      }
    });
  }

  async function runPipelineStepper() {
    resetPipeline();
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const delay = prefersReducedMotion ? 40 : 120;

    for (let step = 1; step <= 5; step++) {
      const node = DOM.stepNodes[step - 1];
      const icon = node.querySelector('.node-icon-circle');

      // Active state
      node.className = 'stepper-node active';
      DOM.pipelineProgress.style.width = `${((step - 1) / 4) * 100}%`;

      await wait(delay);

      // Completed state
      node.className = 'stepper-node completed';
      icon.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
      DOM.pipelineProgress.style.width = `${(step / 5) * 100}%`;
    }
  }

  function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /* ==========================================================================
     Renderers (Tabs 1-4)
     ========================================================================== */

  // Tab 1: Commented Code with line-by-line reveal & italic mint comment styling
  function renderCommentedCode(code) {
    DOM.emptyStateResult.style.display = 'none';
    DOM.codeViewerWrapper.style.display = 'block';

    const lines = code.split('\n');
    DOM.codeDisplayBody.innerHTML = '';

    const isPython = state.language === 'python';
    const totalLines = lines.length;
    // Cap animation stagger at 600ms total
    const delayPerLine = Math.min(15, 600 / Math.max(totalLines, 1));
    const animate = state.firstRender;

    lines.forEach((lineText, idx) => {
      const span = document.createElement('span');
      span.className = 'code-line';

      const trimmed = lineText.trim();
      const isComment = isPython
        ? (trimmed.startsWith('#') || trimmed.startsWith('"""') || trimmed.startsWith("'''"))
        : (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*') || trimmed.startsWith('*/') || trimmed.startsWith('///'));

      if (isComment) {
        span.classList.add('is-comment');
      }

      if (animate) {
        span.classList.add('animate-reveal');
        span.style.animationDelay = `${(idx * delayPerLine).toFixed(1)}ms`;
      }

      span.textContent = lineText || ' ';
      DOM.codeDisplayBody.appendChild(span);
    });
  }

  // Tab 2: Summary
  function renderSummary(summary) {
    DOM.emptyStateSummary.style.display = 'none';
    DOM.summaryContentWrapper.style.display = 'flex';

    DOM.summaryWhatItDoes.textContent = summary.whatItDoes || 'No summary available.';
    DOM.summaryComplexityBadge.textContent = summary.timeComplexity || 'O(1)';
    DOM.summaryComplexityText.textContent = `Time Complexity: ${summary.timeComplexity} — ${summary.timeExplanation}`;
    DOM.summarySpaceText.textContent = `Space Complexity: ${summary.spaceComplexity} — ${summary.spaceExplanation}`;

    DOM.summaryIssuesContainer.innerHTML = '';
    if (summary.issues && summary.issues.length > 0) {
      const ul = document.createElement('ul');
      ul.className = 'issues-list';
      summary.issues.forEach(issue => {
        const li = document.createElement('li');
        li.className = 'issue-item';
        li.innerHTML = `
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
          </svg>
          <span>${escapeHTML(issue)}</span>
        `;
        ul.appendChild(li);
      });
      DOM.summaryIssuesContainer.appendChild(ul);
    } else {
      DOM.summaryIssuesContainer.innerHTML = `
        <div class="clean-state">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          No obvious issues detected
        </div>
      `;
    }
  }

  // Tab 3: Detected Elements Collapsible Tree
  function renderElementsTree(elements) {
    DOM.emptyStateElements.style.display = 'none';
    DOM.elementsContentWrapper.style.display = 'block';
    DOM.elementsTreeRoot.innerHTML = '';

    const categories = [
      { key: 'classes', title: 'Classes & Structs', badge: 'class', badgeClass: 'badge-class' },
      { key: 'functions', title: 'Functions & Methods', badge: 'fn', badgeClass: 'badge-fn' },
      { key: 'params', title: 'Parameters', badge: 'param', badgeClass: 'badge-param' },
      { key: 'loops', title: 'Loops', badge: 'loop', badgeClass: 'badge-loop' },
      { key: 'conditions', title: 'Conditions & Branches', badge: 'cond', badgeClass: 'badge-cond' }
    ];

    let totalItems = 0;

    categories.forEach(cat => {
      const items = elements[cat.key] || [];
      if (items.length === 0) return;
      totalItems += items.length;

      items.forEach(item => {
        const li = document.createElement('li');
        li.className = 'tree-node expanded';

        const nameText = item.name ? `${item.name}${item.detail ? ` ${item.detail}` : ''}` : item.detail;

        li.innerHTML = `
          <div class="tree-node-header">
            <div class="tree-node-left">
              <svg class="tree-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
              <span class="type-badge ${cat.badgeClass}">${cat.badge}</span>
              <span class="tree-node-name">${escapeHTML(nameText)}</span>
            </div>
            <span class="tree-node-line">L${item.line}</span>
          </div>
          <div class="tree-node-children">
            Type: ${cat.title} • Line ${item.line}
          </div>
        `;

        li.querySelector('.tree-node-header').addEventListener('click', () => {
          li.classList.toggle('expanded');
        });

        DOM.elementsTreeRoot.appendChild(li);
      });
    });

    if (totalItems === 0) {
      DOM.elementsTreeRoot.innerHTML = `
        <li style="padding: 1rem; color: var(--muted); text-align: center;">No distinct code elements detected.</li>
      `;
    }
  }

  // Tab 4: Diff View
  function renderDiff(diffRows) {
    DOM.emptyStateDiff.style.display = 'none';
    DOM.diffContentWrapper.style.display = 'block';
    DOM.diffRowsContainer.innerHTML = '';

    const table = document.createElement('div');
    table.className = 'diff-table';

    diffRows.forEach(row => {
      const rowDiv = document.createElement('div');
      rowDiv.className = `diff-row diff-${row.type}`;

      const numCol = document.createElement('div');
      numCol.className = 'diff-line-num';
      numCol.textContent = row.commLineNum || row.origLineNum || '';

      const contentCol = document.createElement('div');
      contentCol.className = 'diff-line-content';
      const prefix = row.type === 'added' ? '+ ' : (row.type === 'modified' ? '~ ' : '  ');
      contentCol.textContent = prefix + (row.content || '');

      rowDiv.appendChild(numCol);
      rowDiv.appendChild(contentCol);
      table.appendChild(rowDiv);
    });

    DOM.diffRowsContainer.appendChild(table);
  }

  /* ==========================================================================
     Toast Notifications
     ========================================================================== */
  function showToast(message, type = 'info', options = {}) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', 'alert');

    let iconSvg = '';
    if (type === 'success') {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
    } else if (type === 'error') {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`;
    } else {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
    }

    let actionBtnHtml = '';
    if (options.actionText) {
      actionBtnHtml = `<button type="button" class="toast-action">${escapeHTML(options.actionText)}</button>`;
    }

    toast.innerHTML = `
      ${iconSvg}
      <div class="toast-content">
        <span class="toast-title">${type === 'error' ? 'Notice' : capitalize(type)}</span>
        <span class="toast-message">${escapeHTML(message)}</span>
        ${actionBtnHtml}
      </div>
    `;

    if (options.actionText && options.onAction) {
      const btn = toast.querySelector('.toast-action');
      if (btn) {
        btn.addEventListener('click', () => {
          options.onAction();
          dismissToast(toast);
        });
      }
    }

    DOM.toastContainer.appendChild(toast);

    const autoDismissTimeout = setTimeout(() => {
      dismissToast(toast);
    }, options.duration || 3800);

    toast.addEventListener('click', (e) => {
      if (!e.target.classList.contains('toast-action')) {
        clearTimeout(autoDismissTimeout);
        dismissToast(toast);
      }
    });
  }

  function dismissToast(toast) {
    if (!toast || toast.classList.contains('toast-exit')) return;
    toast.classList.add('toast-exit');
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 220);
  }

  /* ==========================================================================
     Utilities
     ========================================================================== */
  function capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  function escapeHTML(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  window.CodeCommenterApp = {
    state,
    getSourceCode,
    setSourceCode,
    loadLanguageSample,
    handleGenerate
  };

  // Start app on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
