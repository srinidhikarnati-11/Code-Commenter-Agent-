/**
 * Code Commenter Agent - Multi-Language Rule & Analysis Engine
 * Supports: Python, JavaScript, TypeScript, Java, C++, Go, Rust
 */

(function (global) {
  'use strict';

  // Sample code snippets for all 7 languages
  const SAMPLES = {
    python: `def factorial(n: int) -> int:
    """Calculate the factorial of a non-negative integer."""
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    if n == 0 or n == 1:
        return 1
    
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

class MathSeries:
    def __init__(self, limit: int = 10):
        self.limit = limit

    def compute_sequence(self):
        items = []
        for i in range(self.limit):
            if i % 2 == 0:
                items.append(factorial(i))
            else:
                items.append(i * 2)
        return items`,

    javascript: `function debounce(func, wait, immediate) {
  let timeout;
  return function executedFunction(...args) {
    const context = this;
    const later = function() {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}

class CacheManager {
  constructor(maxSize = 100) {
    this.maxSize = maxSize;
    this.cache = new Map();
  }

  get(key) {
    if (!this.cache.has(key)) return null;
    const value = this.cache.get(key);
    this.cache.delete(key);
    this.cache.set(key, value);
    return value;
  }
}`,

    typescript: `interface UserSession {
  userId: string;
  token: string;
  expiresAt: number;
}

class SessionStore {
  private sessions: Map<string, UserSession> = new Map();

  constructor(private readonly ttlSeconds: number = 3600) {}

  public registerSession(userId: string, token: string): UserSession {
    const expiresAt = Date.now() + this.ttlSeconds * 1000;
    const session: UserSession = { userId, token, expiresAt };
    this.sessions.set(token, session);
    return session;
  }

  public validate(token: string): boolean {
    const session = this.sessions.get(token);
    if (!session) return false;
    if (Date.now() > session.expiresAt) {
      this.sessions.delete(token);
      return false;
    }
    return true;
  }
}`,

    java: `package com.agent.util;

import java.util.ArrayList;
import java.util.List;

public class BinarySearchTree {
    static class Node {
        int key;
        Node left, right;

        public Node(int item) {
            this.key = item;
            this.left = this.right = null;
        }
    }

    private Node root;

    public void insert(int key) {
        this.root = insertRec(this.root, key);
    }

    private Node insertRec(Node current, int key) {
        if (current == null) {
            return new Node(key);
        }
        if (key < current.key) {
            current.left = insertRec(current.left, key);
        } else if (key > current.key) {
            current.right = insertRec(current.right, key);
        }
        return current;
    }
}`,

    cpp: `#include <iostream>
#include <vector>
#include <algorithm>

template <typename T>
class QuickSorter {
public:
    static void sort(std::vector<T>& arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            sort(arr, low, pi - 1);
            sort(arr, pi + 1, high);
        }
    }

private:
    static int partition(std::vector<T>& arr, int low, int high) {
        T pivot = arr[high];
        int i = (low - 1);
        for (int j = low; j <= high - 1; j++) {
            if (arr[j] < pivot) {
                i++;
                std::swap(arr[i], arr[j]);
            }
        }
        std::swap(arr[i + 1], arr[high]);
        return (i + 1);
    }
};`,

    go: `package algorithm

import (
	"errors"
	"sync"
)

type WorkerPool struct {
	tasks   chan func()
	workers int
	wg      sync.WaitGroup
}

func NewWorkerPool(workers int, queueSize int) (*WorkerPool, error) {
	if workers <= 0 {
		return nil, errors.New("worker count must be positive")
	}
	return &WorkerPool{
		tasks:   make(chan func(), queueSize),
		workers: workers,
	}, nil
}

func (p *WorkerPool) Start() {
	for i := 0; i < p.workers; i++ {
		p.wg.Add(1)
		go func() {
			defer p.wg.Done()
			for task := range p.tasks {
				task()
			}
		}()
	}
}`,

    rust: `use std::collections::HashMap;

pub struct LRUCache<K, V> {
    capacity: usize,
    items: HashMap<K, V>,
    order: Vec<K>,
}

impl<K: Clone + Eq + std::hash::Hash, V> LRUCache<K, V> {
    pub fn new(capacity: usize) -> Self {
        LRUCache {
            capacity,
            items: HashMap::new(),
            order: Vec::new(),
        }
    }

    pub fn get(&mut self, key: &K) -> Option<&V> {
        if self.items.contains_key(key) {
            if let Some(pos) = self.order.iter().position(|x| x == key) {
                let k = self.order.remove(pos);
                self.order.push(k);
            }
            self.items.get(key)
        } else {
            None
        }
    }
}`
  };

  const LANGUAGES = [
    { id: 'python', name: 'Python', ext: '.py', color: '#3572A5', commentChar: '#' },
    { id: 'javascript', name: 'JavaScript', ext: '.js', color: '#f1e05a', commentChar: '//' },
    { id: 'typescript', name: 'TypeScript', ext: '.ts', color: '#3178c6', commentChar: '//' },
    { id: 'java', name: 'Java', ext: '.java', color: '#b07219', commentChar: '//' },
    { id: 'cpp', name: 'C++', ext: '.cpp', color: '#f34b7d', commentChar: '//' },
    { id: 'go', name: 'Go', ext: '.go', color: '#00ADD8', commentChar: '//' },
    { id: 'rust', name: 'Rust', ext: '.rs', color: '#dea584', commentChar: '//' }
  ];

  function parseCodeStructure(code, language) {
    const lines = (code || '').split('\n');
    const elements = {
      functions: [],
      classes: [],
      params: [],
      loops: [],
      conditions: []
    };

    const isPython = language === 'python';

    lines.forEach((line, index) => {
      const lineNum = index + 1;
      const trimmed = line.trim();

      if (!trimmed || (isPython ? trimmed.startsWith('#') : trimmed.startsWith('//') || trimmed.startsWith('/*'))) {
        return;
      }

      // Classes
      let classMatch = null;
      if (isPython) {
        classMatch = trimmed.match(/^class\s+([A-Za-z0-9_]+)(?:\(([^)]*)\))?:/);
      } else if (language === 'rust') {
        classMatch = trimmed.match(/^(?:pub\s+)?(?:struct|enum|trait|impl(?:<[^>]+>)?)\s+([A-Za-z0-9_]+)/);
      } else if (language === 'go') {
        classMatch = trimmed.match(/^type\s+([A-Za-z0-9_]+)\s+(?:struct|interface)/);
      } else {
        classMatch = trimmed.match(/^(?:export\s+)?(?:public|private|protected|static|abstract)*\s*(?:class|interface|struct)\s+([A-Za-z0-9_]+)/);
      }

      if (classMatch) {
        elements.classes.push({
          name: classMatch[1],
          line: lineNum,
          type: 'class',
          detail: trimmed.slice(0, 60)
        });
      }

      // Functions
      let fnMatch = null;
      let fnParams = '';
      if (isPython) {
        fnMatch = trimmed.match(/^(?:async\s+)?def\s+([A-Za-z0-9_]+)\s*\(([^)]*)\)/);
        if (fnMatch) fnParams = fnMatch[2];
      } else if (language === 'rust') {
        fnMatch = trimmed.match(/^(?:pub\s+)?(?:async\s+)?fn\s+([A-Za-z0-9_]+)\s*(?:<[^>]+>)?\s*\(([^)]*)\)/);
        if (fnMatch) fnParams = fnMatch[2];
      } else if (language === 'go') {
        fnMatch = trimmed.match(/^func\s+(?:\([^)]+\)\s+)?([A-Za-z0-9_]+)\s*\(([^)]*)\)/);
        if (fnMatch) fnParams = fnMatch[2];
      } else if (language === 'javascript' || language === 'typescript') {
        fnMatch = trimmed.match(/^(?:async\s+)?(?:function\s+([A-Za-z0-9_]+)|(?:const|let|var)\s+([A-Za-z0-9_]+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>|(?:public|private|protected|static|async)*\s*([A-Za-z0-9_]+)\s*\([^)]*\))/);
        const name = fnMatch ? (fnMatch[1] || fnMatch[2] || fnMatch[3]) : null;
        if (fnMatch && name && !['if', 'for', 'while', 'switch', 'catch'].includes(name)) {
          const pMatch = trimmed.match(/\(([^)]*)\)/);
          fnParams = pMatch ? pMatch[1] : '';
          elements.functions.push({
            name: name,
            line: lineNum,
            type: 'function',
            detail: '(' + fnParams.trim() + ')'
          });
          fnMatch = null;
        }
      } else {
        fnMatch = trimmed.match(/(?:public|private|protected|static|final|native|synchronized|template\s*<[^>]+>|inline)*\s*(?:[A-Za-z0-9_<>,\\[\]]+\s+)+([A-Za-z0-9_]+)\s*\(([^)]*)\)\s*(?:const|noexcept|throws\s+[A-Za-z0-9_]+)?\s*[{;]?$/);
        if (fnMatch && !['if', 'for', 'while', 'switch', 'catch', 'return'].includes(fnMatch[1])) {
          fnParams = fnMatch[2];
        } else {
          fnMatch = null;
        }
      }

      if (fnMatch) {
        elements.functions.push({
          name: fnMatch[1],
          line: lineNum,
          type: 'function',
          detail: '(' + fnParams.trim() + ')'
        });
      }

      // Parameters
      if (fnParams && fnParams.trim()) {
        const rawParams = fnParams.split(',');
        rawParams.forEach(p => {
          const cleanP = p.trim().replace(/^self\b|^this\b/, '').trim();
          if (cleanP) {
            elements.params.push({
              name: cleanP.split(/[:=\s]/)[0],
              raw: cleanP,
              line: lineNum,
              type: 'param'
            });
          }
        });
      }

      // Loops
      if (/^(?:for|while|do)\b/.test(trimmed)) {
        elements.loops.push({
          type: 'loop',
          detail: trimmed.slice(0, 45),
          line: lineNum
        });
      }

      // Conditions
      if (/^(?:if|elif|else\s+if|else:|else\b|switch|case|match)\b/.test(trimmed)) {
        elements.conditions.push({
          type: 'condition',
          detail: trimmed.slice(0, 45),
          line: lineNum
        });
      }
    });

    return elements;
  }

  function generateComments(code, language, style) {
    const lines = (code || '').split('\n');
    const resultLines = [];
    const isPython = language === 'python';
    const cChar = isPython ? '#' : '//';

    let inExistingBlockComment = false;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();
      const indentMatch = line.match(/^(\s*)/);
      const indent = indentMatch ? indentMatch[0] : '';

      if (!isPython) {
        if (trimmed.startsWith('/*')) inExistingBlockComment = true;
        if (inExistingBlockComment) {
          resultLines.push(line);
          if (trimmed.includes('*/')) inExistingBlockComment = false;
          continue;
        }
      }

      if (!trimmed || (isPython ? trimmed.startsWith('#') : trimmed.startsWith('//'))) {
        resultLines.push(line);
        continue;
      }

      let commentToAdd = null;

      const isClass = isPython
        ? /^class\s+([A-Za-z0-9_]+)/.test(trimmed)
        : /^(?:export\s+)?(?:public|private|protected|static|abstract)*\s*(?:class|struct|interface|type\s+[A-Za-z0-9_]+\s+(?:struct|interface)|impl)\s+([A-Za-z0-9_]+)/.test(trimmed);

      let fnMatch = null;
      if (isPython) {
        fnMatch = trimmed.match(/^(?:async\s+)?def\s+([A-Za-z0-9_]+)\s*\(([^)]*)\)(?:\s*->\s*([A-Za-z0-9_\[\],\s]+))?:/);
      } else if (language === 'rust') {
        fnMatch = trimmed.match(/^(?:pub\s+)?(?:async\s+)?fn\s+([A-Za-z0-9_]+)\s*(?:<[^>]+>)?\s*\(([^)]*)\)(?:\s*->\s*([^{]+))?/);
      } else if (language === 'go') {
        fnMatch = trimmed.match(/^func\s+(?:\([^)]+\)\s+)?([A-Za-z0-9_]+)\s*\(([^)]*)\)(?:\s*\(([^)]*)\)|\s*([^{]+))?/);
      } else if (language === 'javascript' || language === 'typescript') {
        const m = trimmed.match(/^(?:export\s+)?(?:async\s+)?(?:function\s+([A-Za-z0-9_]+)|(?:const|let|var)\s+([A-Za-z0-9_]+)\s*=\s*(?:async\s*)?\(([^)]*)\)|(?:public|private|protected|static|async)*\s*([A-Za-z0-9_]+)\s*\(([^)]*)\))/);
        if (m) {
          const fnName = m[1] || m[2] || m[4];
          if (fnName && !['if', 'for', 'while', 'switch'].includes(fnName)) {
            fnMatch = [trimmed, fnName, m[3] || m[5] || ''];
          }
        }
      } else {
        const m = trimmed.match(/(?:public|private|protected|static|final|template\s*<[^>]+>)*\s*([A-Za-z0-9_<>,\\[\]]+)\s+([A-Za-z0-9_]+)\s*\(([^)]*)\)/);
        if (m && !['if', 'for', 'while', 'switch'].includes(m[2])) {
          fnMatch = [trimmed, m[2], m[3], m[1]];
        }
      }

      const isLoop = /^(?:for|while|do)\b/.test(trimmed);
      const isCondition = /^(?:if|elif|else\s+if|switch|match)\b/.test(trimmed);
      const isReturn = /^(?:return|throw|raise)\b/.test(trimmed);

      if (isClass) {
        const classNameMatch = trimmed.match(/(?:class|struct|interface|type)\s+([A-Za-z0-9_]+)/);
        const name = classNameMatch ? classNameMatch[1] : 'Component';
        if (style === 'concise') {
          commentToAdd = `${indent}${cChar} Encapsulates ${name} state and lifecycle`;
        } else if (style === 'detailed') {
          commentToAdd = `${indent}${cChar} ${name}: Primary entity definition.\n${indent}${cChar} Coordinates internal states, invariants, and operational methods.`;
        } else {
          if (isPython) {
            commentToAdd = null;
          } else if (language === 'rust') {
            commentToAdd = `${indent}/// \`${name}\` structure representing core operational domain.\n${indent}/// Maintains required invariants and thread safety.`;
          } else {
            commentToAdd = `${indent}/**\n${indent} * Represents the ${name} component.\n${indent} * Manages structured instance attributes and behaviors.\n${indent} */`;
          }
        }
      } else if (fnMatch) {
        const fnName = fnMatch[1];
        const rawParams = (fnMatch[2] || '').split(',').map(s => s.trim().replace(/^self\b|^this\b/, '').trim()).filter(Boolean);

        if (style === 'concise') {
          const humanName = fnName.replace(/([A-Z])/g, ' $1').replace(/_/g, ' ').toLowerCase();
          commentToAdd = `${indent}${cChar} Executes ${humanName.trim()} logic`;
        } else if (style === 'detailed') {
          const humanName = fnName.replace(/([A-Z])/g, ' $1').replace(/_/g, ' ').toLowerCase();
          commentToAdd = `${indent}${cChar} [${fnName}] - Implements ${humanName.trim()}\n${indent}${cChar} Validates parameters, executes core transformation, and ensures safe returns.`;
        } else {
          if (isPython) {
            resultLines.push(line);
            const docIndent = indent + '    ';
            let doc = `${docIndent}"""\n${docIndent}Perform ${fnName.replace(/_/g, ' ')} operations.\n`;
            if (rawParams.length > 0) {
              doc += `\n${docIndent}Args:\n`;
              rawParams.forEach(p => {
                const pName = p.split(/[:=]/)[0].trim();
                doc += `${docIndent}    ${pName}: Expected input parameter.\n`;
              });
            }
            doc += `\n${docIndent}Returns:\n${docIndent}    Computed result or status code.\n${docIndent}"""`;
            resultLines.push(doc);
            continue;
          } else if (language === 'rust') {
            let rustDoc = `${indent}/// ${fnName.replace(/_/g, ' ')}\n`;
            if (rawParams.length > 0) {
              rustDoc += `${indent}///\n${indent}/// # Arguments\n`;
              rawParams.forEach(p => {
                const pName = p.split(':')[0].trim();
                rustDoc += `${indent}/// * \`${pName}\` - Input parameter value\n`;
              });
            }
            rustDoc += `${indent}///\n${indent}/// # Returns\n${indent}/// Resulting output value`;
            commentToAdd = rustDoc;
          } else if (language === 'go') {
            commentToAdd = `${indent}// ${fnName} computes and executes the desired operation for callers.`;
          } else {
            let doc = `${indent}/**\n${indent} * ${fnName.replace(/([A-Z])/g, ' $1').toLowerCase()}\n`;
            rawParams.forEach(p => {
              const pName = p.split(/[:\s]/)[0].trim();
              doc += `${indent} * @param ${pName} Contextual input argument\n`;
            });
            doc += `${indent} * @returns {any} Evaluated response\n${indent} */`;
            commentToAdd = doc;
          }
        }
      } else if (isLoop) {
        if (style === 'concise') {
          commentToAdd = `${indent}${cChar} Iterate through sequential elements`;
        } else if (style === 'detailed') {
          commentToAdd = `${indent}${cChar} Iteration loop: processes collection elements sequentially until completion`;
        }
      } else if (isCondition) {
        if (style === 'concise') {
          commentToAdd = `${indent}${cChar} Check boundary / precondition`;
        } else if (style === 'detailed') {
          commentToAdd = `${indent}${cChar} Guard clause: evaluate conditional branch and enforce preconditions`;
        }
      } else if (isReturn && (style === 'detailed')) {
        commentToAdd = `${indent}${cChar} Yield finalized result to caller`;
      }

      if (commentToAdd) {
        resultLines.push(commentToAdd);
      }
      resultLines.push(line);
    }

    return resultLines.join('\n');
  }

  function analyzeSummaryAndComplexity(code, language, elements) {
    const lines = (code || '').split('\n').filter(l => l.trim().length > 0);
    const loopCount = elements.loops.length;
    const fnCount = elements.functions.length;
    const classCount = elements.classes.length;

    let timeComplexity = 'O(1)';
    let timeExplanation = 'Constant time operations with direct sequential execution.';

    if (loopCount === 1) {
      timeComplexity = 'O(n)';
      timeExplanation = 'Linear scan iterating across input sequences or bounded ranges.';
    } else if (loopCount === 2) {
      timeComplexity = 'O(n²) or O(n log n)';
      timeExplanation = 'Nested iterations or divide-and-conquer partitioning.';
    } else if (loopCount > 2) {
      timeComplexity = `O(n^${loopCount})`;
      timeExplanation = 'Multiple nested loops detected; consider optimizing lookups with hash maps.';
    } else if (code.includes('log') || code.includes('binary') || code.includes('divide') || code.includes('partition')) {
      timeComplexity = 'O(log n)';
      timeExplanation = 'Logarithmic execution time typical of binary search or balanced tree traversals.';
    }

    let spaceComplexity = 'O(1)';
    let spaceExplanation = 'Auxiliary in-place memory usage with fixed variables.';
    if (code.includes('append') || code.includes('push') || code.includes('new Map') || code.includes('new ArrayList') || code.includes('Vec::new') || code.includes('make(chan')) {
      spaceComplexity = 'O(n)';
      spaceExplanation = 'Linear auxiliary memory allocating dynamic collection structures.';
    }

    const issues = [];
    if (code.includes('/ 0') || code.includes('/0')) {
      issues.push('Potential division by zero detected in arithmetic operations.');
    }
    if (code.includes('any') && (language === 'typescript')) {
      issues.push("Unsafe 'any' type annotation used; consider narrowing to explicit types.");
    }
    if (code.includes('var ') && (language === 'javascript' || language === 'typescript')) {
      issues.push("Legacy 'var' declarations detected; prefer block-scoped 'const' or 'let'.");
    }
    if (isRecursive(code, elements)) {
      issues.push('Recursive invocation detected; ensure base case termination to prevent stack overflow on deep inputs.');
    }
    if (code.length > 15000) {
      issues.push('Large input source: consider modularizing into cohesive submodules.');
    }

    let whatItDoes = '';
    const mainFns = elements.functions.map(f => f.name);
    const mainClasses = elements.classes.map(c => c.name);

    if (mainClasses.length > 0) {
      whatItDoes = `Defines ${mainClasses.join(', ')} component architecture. `;
    }
    if (mainFns.length > 0) {
      whatItDoes += `Implements algorithmic routines including ${mainFns.slice(0, 3).join(', ')}${mainFns.length > 3 ? ' and others' : ''}.`;
    } else if (lines.length > 0) {
      whatItDoes += `Performs structured procedural execution in ${language.toUpperCase()}.`;
    } else {
      whatItDoes = 'Empty code source provided.';
    }

    return {
      whatItDoes,
      timeComplexity,
      timeExplanation,
      spaceComplexity,
      spaceExplanation,
      issues,
      metrics: {
        linesOfCode: lines.length,
        functions: fnCount,
        classes: classCount,
        loops: loopCount,
        conditions: elements.conditions.length
      }
    };
  }

  function isRecursive(code, elements) {
    for (const fn of elements.functions) {
      const regex = new RegExp(`\\b${fn.name}\\s*\\(`, 'g');
      const matches = code.match(regex);
      if (matches && matches.length > 1) {
        return true;
      }
    }
    return false;
  }

  function generateDiff(originalCode, commentedCode, language) {
    const origLines = (originalCode || '').split('\n');
    const commLines = (commentedCode || '').split('\n');
    const isPython = language === 'python';

    const diffRows = [];
    let origIdx = 0;
    let commIdx = 0;

    while (commIdx < commLines.length) {
      const cLine = commLines[commIdx];
      const trimmed = cLine.trim();
      const isComment = isPython
        ? (trimmed.startsWith('#') || trimmed.startsWith('"""') || trimmed.startsWith("'''"))
        : (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*') || trimmed.startsWith('*/') || trimmed.startsWith('///'));

      if (origIdx < origLines.length && origLines[origIdx] === cLine) {
        diffRows.push({
          type: 'unchanged',
          origLineNum: origIdx + 1,
          commLineNum: commIdx + 1,
          content: cLine
        });
        origIdx++;
        commIdx++;
      } else if (isComment) {
        diffRows.push({
          type: 'added',
          origLineNum: '',
          commLineNum: commIdx + 1,
          content: cLine
        });
        commIdx++;
      } else {
        diffRows.push({
          type: 'modified',
          origLineNum: origIdx < origLines.length ? origIdx + 1 : '',
          commLineNum: commIdx + 1,
          content: cLine
        });
        origIdx++;
        commIdx++;
      }
    }

    return diffRows;
  }

  const engine = {
    LANGUAGES,
    SAMPLES,
    parseCodeStructure,
    generateComments,
    analyzeSummaryAndComplexity,
    generateDiff
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = engine;
  }
  global.CodeCommenterEngine = engine;

})(typeof window !== 'undefined' ? window : this);
